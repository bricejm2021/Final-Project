package com.example.actualfinalproject;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Credentials {

    private String Username;
    private String Password;
    private ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();


    private ArrayList<CreditCard> ccAccounts = new ArrayList<>();
    Credentials(String username, String password){
        this.Username = username;
        this.Password = password;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public void addBankAccount(BankAccount account){
        accounts.add(account);
    }

    public void addCC (CreditCard account)
    {
        ccAccounts.add(account);
    }

    public ArrayList<CreditCard> getCcAccounts() {
        return ccAccounts;
    }
    public ArrayList<BankAccount> getAccounts() {
        return accounts;
    }
}
