package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class viewAccounts extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
    private ArrayList<CreditCard> ccaccounts = new ArrayList<>();
    private RecyclerView.Adapter adapter;
    //editAttemptsInfo = findViewById(R.id.txtAttemptsInfo);
     //editAttemptsInfo.setText("Number of attempts remaining: " + counter);
    private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_accounts);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        accounts = RegistrationActivity.credentials.getAccounts();
        ccaccounts = RegistrationActivity.credentials.getCcAccounts();
        listItems = new ArrayList<>(20);
        String x = "";
        for(int i = 0; i < accounts.size(); i++)
        {
            x = String.valueOf(accounts.get(i).getBalance());
            ListItem listItem = new ListItem("Bank: " + accounts.get(i).getBankName(),"Account Balance: " +  x);
            ListItem ccList = new ListItem("CC: " + ccaccounts.get(i).getCardNumber(), "Expirate Date" + ccaccounts.get(i).getExpDate());
           // ListItem listItem = new ListItem("Sample text for you", "Hello there");

            listItems.add(listItem);
        }
        for(int i = 0; i < ccaccounts.size(); i++)
        {
            //x = String.valueOf(accounts.get(i).getBalance());
            //ListItem listItem = new ListItem("Bank: " + accounts.get(i).getBankName(),"Account Balance: " +  x);

            ListItem ccList = new ListItem("Card Nickname:  " + ccaccounts.get(i).getNickname(), "Expiration Date: " + ccaccounts.get(i).getExpDate());
            // ListItem listItem = new ListItem("Sample text for you", "Hello there");

            listItems.add(ccList);
        }
        adapter = new Bank(listItems, this);
        recyclerView.setAdapter(adapter);
        //welcomeUser.setText("Welcome " + RegistrationActivity.credentials.getUsername());

    }

}