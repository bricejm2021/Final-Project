package com.example.actualfinalproject;

import android.widget.EditText;

public class CreditCard {

    private EditText editCardNum;
    private EditText editExpDate;
    private EditText editSecurityNum;
    private String CardNumber;
    private String ExpDate;
    private String securityNum;
    private String nickname;


    public String getCardNumber() {
        return CardNumber;
    }

    public String getExpDate() {
        return ExpDate;
    }

    public String getSecurityNum() {
        return securityNum;
    }

    public String getNickname() {
        return nickname;
    }

    public CreditCard(String cardNumber, String expDate, String securityNum, String nickname) {
        this.CardNumber = cardNumber;
        this.ExpDate = expDate;
        this.securityNum = securityNum;
        this.nickname = nickname;
    }
}
