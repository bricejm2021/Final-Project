package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class HomePageActivity extends AppCompatActivity {
    //Variables
    private Button addBankAccount;
    private Button addPaymentMethod;
    private Button editTransfer;
    private Button editMakePurchase;
    private Button editAccounts;
    private Button editSettings;
    private TextView welcomeUser;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        addBankAccount = findViewById(R.id.btnAddBank);
        addPaymentMethod = findViewById(R.id.btnAddPaymentMethod);
        editTransfer = findViewById(R.id.btnTransferMoney);
        editMakePurchase = findViewById(R.id.btnMakePurchase);
        editAccounts = findViewById(R.id.btnViewAccounts);
        editSettings = findViewById(R.id.btnSettings);
        welcomeUser = findViewById(R.id.txtWelcomeUser);
        if(MainActivity.p == true)
        {
            Toast.makeText(HomePageActivity.this, "Purchase Complete.", Toast.LENGTH_LONG).show();
            MainActivity.p = false;
        }
        welcomeUser.setText("Welcome " + RegistrationActivity.credentials.getUsername());

        addBankAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePageActivity.this, ActivityAddBank.class));
            }
        });
        editAccounts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomePageActivity.this, viewAccounts.class));
            }
        });
        addPaymentMethod.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(HomePageActivity.this, ActivityAddCreditCard.class));
            }
        });
        editMakePurchase.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(HomePageActivity.this, MakePayment.class));
            }
        });

    }
}