package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrationActivity extends AppCompatActivity {
    //Variables
    private EditText editRegisterName;
    private EditText editRegisterEmail;
    private EditText editRegisterPassword;
    private Button editRegister;

    public static Credentials credentials;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regristration);

        editRegisterName = findViewById(R.id.txtRegisteredName);
        editRegisterEmail = findViewById(R.id.txtRegisteredEmail);
        editRegisterPassword = findViewById(R.id.txtRegisteredPassword);
        editRegister = findViewById(R.id.btnRegister);

        editRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String regUsername = editRegisterName.getText().toString();
                String regPassword = editRegisterPassword.getText().toString();

                if(validate(regUsername, regPassword)){
                    credentials = new Credentials(regUsername, regPassword);
                    Intent intent = new Intent(RegistrationActivity.this, MainActivity.class);
                    startActivity(intent);
                    Toast.makeText(RegistrationActivity.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private boolean validate(String username, String password){

        if(username.isEmpty() || password.length() < 8){
            Toast.makeText(this, "Please enter all the details, password should be at least 8 characters!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}