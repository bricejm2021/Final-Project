package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ActivityAddCreditCard extends AppCompatActivity
{

    private EditText editCardNumber;
    private EditText editExpDate;
    private EditText editSecurityCode;
    private EditText nickname;
    private Button SaveCard;
    private Button home;
    public CreditCard cc;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_credit_card);
        editCardNumber = findViewById(R.id.cardNumber);
        editExpDate = findViewById(R.id.ExpDate);
        editSecurityCode = findViewById(R.id.SecCode);
        SaveCard = findViewById(R.id.addCard);
        nickname = findViewById(R.id.nickname);
        home = findViewById(R.id.cardHome);


     /*   editSaveBank.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                String routingNumber = editRoutingNumber.getText().toString();
                String accountNumber = editAccountNumber.getText().toString();
                String confirmAccountNumber = editConfirmAccountNumber.getText().toString();
                String bankName = editBankName.getText().toString();
                balance = (double)(Math.random() * 3000) + 500;

                if(validate(accountNumber, confirmAccountNumber, routingNumber, bankName))
                {
                    bankAccount = new BankAccount(accountNumber, bankName, balance);
                    RegistrationActivity.credentials.addBankAccount(bankAccount);
                    Toast.makeText(ActivityAddBank.this, "Bank Added", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ActivityAddBank.this, HomePageActivity.class));

                }

            }
        });*/
        SaveCard.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                String cardNum = editCardNumber.getText().toString();
                String scrtyCode = editSecurityCode.getText().toString();
                String date = editExpDate.getText().toString();
                String d = date.substring(0,2);
                String e = date.substring(2,4);
                date = d + "/" + e;
                String name = nickname.getText().toString();
                if(validate(cardNum,0) && validate(scrtyCode,1) && validate(date,2))
                {
                    cc= new CreditCard(chk(cardNum, 0),chk(date, 2), chk(scrtyCode,1), name);
                    RegistrationActivity.credentials.addCC(cc);
                    Toast.makeText(ActivityAddCreditCard.this, "Card Added", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ActivityAddCreditCard.this, HomePageActivity.class));
                }
            }
        });

    }

    public boolean validate (String x, int y)
    {
        if(y == 0)
        {
            if(x.length() > 14 &&  x.length() < 17)
            {
                //chk(x, 0);
                return true;
            }
        }
        if(y == 1)
        {
            if(x.length() > 0 && x.length() < 6)
            {
                //chk(x, y);
                return true;
            }
        }
        if(y == 2)
        {
            if(x.length() ==5 )
            {
                //chk(x, y);
                return true;
            }
        }
        Toast.makeText(ActivityAddCreditCard.this, "Please validate Information.", Toast.LENGTH_SHORT).show();
            return false;
    }

    public String chk(String x, int y)
    {
        if(y == 0)
        {
            return x;
        }
        if(y == 1)
        {
            return x;
        }
        if(y == 2)
        {
            return x;
        }
        return "x";
    }
}
