package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Variables
    public static boolean p = false;
    private EditText editName;
    private EditText editPassword;
    private Button editLogin;
    private TextView editAttemptsInfo;
    private TextView editSignUp;

    boolean isValid = false;
    private int counter = 5;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editName = findViewById(R.id.txtName);
        editPassword = findViewById(R.id.txtPassword);
        editLogin = findViewById(R.id.btnLogin);
        editAttemptsInfo = findViewById(R.id.txtAttemptsInfo);
        editSignUp = findViewById(R.id.txtRegister);

        editSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RegistrationActivity.class));
            }
        });

        editLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String inputName = editName.getText().toString();
                String inputPassword = editPassword.getText().toString();

                if(inputName.isEmpty() || inputPassword.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter all the details correctly!", Toast.LENGTH_LONG).show();
                }
                else{
                    isValid = validate(inputName, inputPassword);

                    if(!isValid){
                        counter--;
                        Toast.makeText(MainActivity.this, "Incorrect credentials!", Toast.LENGTH_LONG).show();

                        editAttemptsInfo.setText("Number of attempts remaining: " + counter);

                        if(counter == 0){
                            editLogin.setEnabled(false);
                        }

                    }
                    else{
                        Toast.makeText(MainActivity.this, "Login successful!", Toast.LENGTH_LONG).show();

                        //Add the code to go to new activity
                        Intent intent = new Intent(MainActivity.this, HomePageActivity.class);
                        startActivity(intent);
                    }
                }

            }
        });
    }

    private boolean validate(String name, String password){

        if(RegistrationActivity.credentials != null){
            if(name.equals(RegistrationActivity.credentials.getUsername()) && password.equals(RegistrationActivity.credentials.getPassword())){
                return true;
            }
        }

        return false;
    }
}


