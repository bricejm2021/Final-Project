package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.ArrayList;

public class ActivityAddBank extends AppCompatActivity {

    //Variables
    private EditText editRoutingNumber;
    private EditText editAccountNumber;
    private EditText editConfirmAccountNumber;
    private EditText editBankName;
    private Button editSaveBank;
    private Button home;
    private double balance;

    public BankAccount bankAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_bank);
        home = findViewById(R.id.acctHome);
        editRoutingNumber = findViewById(R.id.editRoutingNumber);
        editAccountNumber = findViewById(R.id.editAccountNumber);
        editConfirmAccountNumber = findViewById(R.id.editConfirmAccountNumber);
        editBankName = findViewById(R.id.editBankName);
        editSaveBank = findViewById(R.id.btnConfirmBank);

        editSaveBank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String routingNumber = editRoutingNumber.getText().toString();
                String accountNumber = editAccountNumber.getText().toString();
                String confirmAccountNumber = editConfirmAccountNumber.getText().toString();
                String bankName = editBankName.getText().toString();
                balance = (double)(Math.random() * 3000) + 500;

                if(validate(accountNumber, confirmAccountNumber, routingNumber, bankName)){
                    bankAccount = new BankAccount(accountNumber, bankName, balance);
                    RegistrationActivity.credentials.addBankAccount(bankAccount);
                    Toast.makeText(ActivityAddBank.this, "Bank Added", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ActivityAddBank.this, HomePageActivity.class));

                }

            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityAddBank.this, HomePageActivity.class));
            }
        });

    }

    private boolean validate(String actNumber, String cfrmAccountNumber, String routeNumber, String bankName){
        if(actNumber.isEmpty()|| !(actNumber.equals(cfrmAccountNumber)) || cfrmAccountNumber.isEmpty() || routeNumber.length() != 9 || bankName.isEmpty()){
            Toast.makeText(this, "Invalid Info!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;

    }
}