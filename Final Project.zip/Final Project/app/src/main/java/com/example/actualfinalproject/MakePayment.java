package com.example.actualfinalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MakePayment extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{
    private ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
    private ArrayList<CreditCard> ccaccounts = new ArrayList<>();
    private Button home;
    private Button mkPurchase;
    private EditText amt;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_make_payment);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        accounts = RegistrationActivity.credentials.getAccounts();
        ccaccounts = RegistrationActivity.credentials.getCcAccounts();
        home = findViewById(R.id.payhome);
        mkPurchase = findViewById(R.id.mkPayment);
        amt = findViewById(R.id.purchaseAmount);
        double d = Double.parseDouble(amt.getText().toString());

        spinner.setOnItemSelectedListener(this);

        List<String> x = new ArrayList<String>();
        // List<String> categories = new ArrayList<String>();
        home.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(MakePayment.this, HomePageActivity.class));
            }
        });
        mkPurchase.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                startActivity(new Intent(MakePayment.this, progressbar.class));
            }
        });
        for (int i = 0; i < accounts.size(); i++)
        {
                x.add(accounts.get(i).getBankName());
        }
        for (int i = 0; i <  ccaccounts.size(); i++)
        {
            x.add(ccaccounts.get(i).getNickname());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, x);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
    {

        String item = parent.getItemAtPosition(position).toString();
        EditText x = findViewById(R.id.acct);
        x.setText(item);

        Toast.makeText(parent.getContext(), "Selected: " + item, Toast.LENGTH_LONG).show();
    }
    public void onNothingSelected(AdapterView<?> arg0)
    {
        // TODO Auto-generated method stub
    }


    public void chgBlnc(double x, BankAccount y)
    {
        double balance = (double)y.getBalance();
    }

}